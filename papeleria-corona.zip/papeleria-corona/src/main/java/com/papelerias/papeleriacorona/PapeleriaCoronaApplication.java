package com.papelerias.papeleriacorona;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PapeleriaCoronaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PapeleriaCoronaApplication.class, args);
	}

}
