package com.papelerias.papeleriacorona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PapeleriaCoronaApplicationTests {

	@Test
	void contextLoads() {
	}

}
